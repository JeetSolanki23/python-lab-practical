from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import uuid
import os
import logging
from flask_sqlalchemy import SQLAlchemy

# Flask app configuration
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # For flash messages
app.config['UPLOAD_FOLDER'] = 'static/products_image/'  # File upload path
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'  # SQLite database
db = SQLAlchemy(app)

# Ensure the upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Product database model
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Integer, nullable=False)
    main_photo_name = db.Column(db.String(100), nullable=False)
    sub_photo_name = db.Column(db.String(100), nullable=False)  # Stores sub-photo filenames as a comma-separated string
    rating = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f"<Product {self.name}>"

@app.route('/addproduct', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        description = request.form['description']
        price = request.form['price']
        rating = request.form['rating']
        category = request.form['category']

        # Handle main photo
        main_photo = request.files['main_photo']
        if main_photo:
            filename = secure_filename(main_photo.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"  # Create unique filename
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            main_photo.save(filepath)  # Save the file
        else:
            flash("Main photo is required")
            return redirect(request.url)

        # Handle sub-photos
        sub_photos = request.files.getlist("sub_photos")
        if len(sub_photos) > 3:
            flash("You can only upload a maximum of 3 sub-images.")
            return redirect(request.url)

        sub_photo_names = []
        for photo in sub_photos:
            filename = secure_filename(photo.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            photo.save(filepath)  # Save each sub-photo
            sub_photo_names.append(unique_filename)

        # Store the product information in the database
        new_product = Product(
            name=name,
            description=description,
            price=price,
            main_photo_name=unique_filename,
            sub_photo_name=",".join(sub_photo_names),
            rating=rating,
            category=category
        )

        db.session.add(new_product)
        db.session.commit()

        flash("Product added successfully!")
        return redirect(url_for('add_product'))

    # If GET request, render the form
    return render_template('add data.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create tables if they don't exist
    app.run(debug=True)  # Start the Flask app
