from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)  # Attach it to the Flask app
login_manager.login_view = 'login'  # Redirect users to 'login' page if they are not authenticated



class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=False, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Integer, nullable=False)  # Changed to Integer
    main_photo_name = db.Column(db.String(100), nullable=False)
    sub_photo_name = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Float)
    category = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return '<Product %r>' % self.name

class UserPurchase(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), nullable=False)  # "cart" or "purchased"

    user = db.relationship('User', backref=db.backref('purchases', lazy=True))
    product = db.relationship('Product', backref=db.backref('purchases', lazy=True))

    def __repr__(self):
        return '<UserPurchase %r>' % self.id

class UserComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    comment = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Integer, nullable=False)

    user = db.relationship('User', backref=db.backref('comments', lazy=True))

    def __repr__(self):
        return '<UserComment %r>' % self.id




@app.route('/')
def index():
    # Add your code to fetch and display products here
    products = Product.query.all()
    return render_template('index.html', products=products)







@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user and user.password == password:  # Check password
            login_user(user)  # Log the user in
            return redirect(url_for('index'))
        else:
            error = 'Invalid username or password'
            return render_template('account.html', error=error)
    return render_template('account.html')

@app.route('/logout')
@login_required  # Only allow logged-in users to log out
def logout():
    logout_user()  # Log the user out
    return redirect(url_for('index'))




@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        # Check if username or email already exists
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            error = 'Email already exists'
            return render_template('account.html', error=error)
        else:
            # Create a new user and add to database
            new_user = User(username=username, email=email, password=password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))  # Redirect to login page after registration
    return render_template('account.html')


@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@login_required  # User must be logged in to add to cart
def add_to_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    user_id = current_user.id  # Get the current logged-in user ID

    new_purchase = UserPurchase(user_id=user_id, product_id=product_id, quantity=quantity, status="cart")
    db.session.add(new_purchase)
    db.session.commit()

    return redirect(url_for('cart'))  # Redirect to the cart page




@app.route('/account')
def account():
    # Add your code to display user account information here
    return render_template('account.html')


@app.route('/products')
def products():
    # Add your code to display the shopping cart here
    products = Product.query.all()
    return render_template('product.html', products=products)

@app.route('/detail/<int:product_id>')
def detail(product_id):
    product = Product.query.get(product_id)
    if product is None:
        return redirect(url_for('products'))  # Redirect if product doesn't exist
    return render_template('detail.html', product=product)



@app.route('/detail1/<int:product_id>')
def detailo(product_id):
    product = Product.query.get(product_id)
    if product is None:
        return redirect(url_for('products'))  # Redirect if product doesn't exist
    return product.sub_photo_name


@app.route('/about')
def about():
    # Add your code to display the shopping cart here
    return render_template('about.html')

@app.route('/contact')
def contact():
    # Add your code to display the shopping cart here
    return render_template('contact.html')


@app.route('/cart')
@login_required
def cart():
    user_id = current_user.id
    cart_items = UserPurchase.query.filter_by(user_id=user_id, status='cart').all()  # Get items in cart for current user

    subtotal = sum(item.product.price * item.quantity for item in cart_items)  # Calculate subtotal
    tax_rate = 0.1  # Example tax rate of 10%
    tax = subtotal * tax_rate
    total = subtotal + tax

    return render_template('cart.html', cart_items=cart_items, subtotal=subtotal, tax=tax, total=total)


@app.route('/remove_from_cart/<int:purchase_id>', methods=['POST', 'GET'])
@login_required
def remove_from_cart(purchase_id):
    # Fetch the purchase record with the given ID and matching current user
    item = UserPurchase.query.filter_by(id=purchase_id, user_id=current_user.id).first()
    if item and item.status == 'cart':
        db.session.delete(item)
        db.session.commit()  # Commit the removal

    # Redirect back to the cart page
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['POST', 'GET'])
@login_required
def checkout():
    user_id = current_user.id

    # Fetch all items in the user's cart
    cart_items = UserPurchase.query.filter_by(user_id=user_id, status='cart').all()

    # Change the status from "cart" to "purchased"
    for item in cart_items:
        item.status = 'purchased'

    # Commit the changes to the database
    db.session.commit()

    # Redirect to the home page after a successful checkout
    return redirect(url_for('index'))



if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0')
